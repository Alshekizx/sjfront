import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight } from 'lucide-react';

export default function PaymentSuccess() {
  const ref = `PSK_${Date.now().toString().slice(-8)}`;

  return (
    <div className="min-h-screen bg-[var(--background)] flex items-center justify-center px-6">
      <div className="w-full max-w-[520px]">
        <div className="bg-white border border-[var(--border)] rounded-2xl p-10 text-center shadow-xl">
          <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={40} className="text-green-600" />
          </div>
          <h1 className="font-serif text-3xl font-bold text-[var(--primary)] mb-2">Payment Successful!</h1>
          <p className="text-[var(--muted-foreground)] mb-8">Your subscription has been activated. You now have full access to your academic level content.</p>

          <div className="bg-[var(--muted)] rounded-xl p-5 text-left mb-8 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-[var(--muted-foreground)]">Reference</span>
              <span className="font-mono text-xs font-medium">{ref}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[var(--muted-foreground)]">Level Unlocked</span>
              <span className="font-medium text-[var(--primary)]">200 Level</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[var(--muted-foreground)]">Amount Paid</span>
              <span className="font-mono font-semibold text-[var(--primary)]">₦14,000</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[var(--muted-foreground)]">Subscription Period</span>
              <span className="font-medium">6 months</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[var(--muted-foreground)]">Expires</span>
              <span className="font-medium">20 Mar 2027</span>
            </div>
          </div>

          <Link
            to="/courses"
            className="flex items-center justify-center gap-2 w-full py-3.5 bg-[var(--primary)] text-white font-semibold rounded-xl hover:bg-[#0a1840] transition-colors mb-3"
          >
            Start Learning <ArrowRight size={16} />
          </Link>
          <Link to="/dashboard" className="block text-sm text-[var(--muted-foreground)] hover:text-[var(--primary)] transition-colors">
            Go to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
