import { CreditCard, CheckCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

const TRANSACTIONS = [
  { ref: 'PSK_REF_001_20260801', level: '100 Level', amount: 12000, status: 'Successful', date: '2026-08-01', method: 'Debit Card' },
];

export default function PaymentHistory() {
  const { user } = useAuth();
  if (!user) return null;

  return (
    <div className="bg-white border border-[var(--border)] rounded-xl p-6">
      <h2 className="font-serif text-xl font-semibold text-[var(--primary)] mb-1">Payment History</h2>
      <p className="text-sm text-[var(--muted-foreground)] mb-6">All your subscription payment transactions</p>

      {TRANSACTIONS.length === 0 ? (
        <div className="text-center py-12">
          <CreditCard size={40} className="text-[var(--muted-foreground)] mx-auto mb-3" />
          <p className="text-[var(--muted-foreground)] text-sm">No payment transactions yet</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[var(--border)]">
                {['Reference', 'Level', 'Amount', 'Status', 'Date', 'Method'].map((h) => (
                  <th key={h} className="text-left text-xs font-semibold uppercase tracking-wider text-[var(--muted-foreground)] pb-3 pr-4">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {TRANSACTIONS.map((tx) => (
                <tr key={tx.ref}>
                  <td className="py-3 pr-4">
                    <span className="font-mono text-xs bg-[var(--muted)] px-2 py-1 rounded">{tx.ref}</span>
                  </td>
                  <td className="py-3 pr-4 font-medium">{tx.level}</td>
                  <td className="py-3 pr-4 font-mono font-semibold text-[var(--primary)]">₦{tx.amount.toLocaleString()}</td>
                  <td className="py-3 pr-4">
                    <span className="flex items-center gap-1.5 text-green-600 text-xs font-semibold">
                      <CheckCircle size={13} /> {tx.status}
                    </span>
                  </td>
                  <td className="py-3 pr-4 text-[var(--muted-foreground)] text-xs">
                    {new Date(tx.date).toLocaleDateString('en-NG', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </td>
                  <td className="py-3 text-[var(--muted-foreground)] text-xs">{tx.method}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
