import { Link } from 'react-router-dom';
import { Scale, BookOpen, Award, Users, ArrowRight } from 'lucide-react';
import logoLight from '@/assets/ref3.png';

export default function About() {
  return (
    <div className="min-h-screen">
      <section className="bg-[var(--primary)] text-white py-16">
        <div className="container-shell">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="block w-12 h-0.5 bg-[var(--accent)] mb-6" />
              <h1 className="font-serif text-4xl md:text-5xl font-bold mb-4">About SJ Law Academy</h1>
              <p className="text-white/70 text-lg leading-relaxed">
                A premium digital learning platform built specifically for Nigerian law students — combining rigorous academic content with a modern learning experience.
              </p>
            </div>
            <div className="flex justify-center">
              <img src={logoLight} alt="SJ Law Academy" className="h-48 w-auto" />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-[900px] mx-auto px-4 sm:px-6">
          <div className="prose prose-lg max-w-none">
            <div className="grid md:grid-cols-2 gap-8 mb-16">
              <div>
                <span className="block w-10 h-0.5 bg-[var(--accent)] mb-4" />
                <h2 className="font-serif text-2xl font-bold text-[var(--primary)] mb-3">Our Mission</h2>
                <p className="text-[var(--muted-foreground)] leading-relaxed">
                  SJ Law Academy was built to address a fundamental gap in legal education in Nigeria: the absence of a structured, accessible, and premium digital learning resource aligned to the Nigerian law curriculum. We believe every law student, regardless of geography or background, deserves access to the highest quality legal education resources.
                </p>
              </div>
              <div>
                <span className="block w-10 h-0.5 bg-[var(--accent)] mb-4" />
                <h2 className="font-serif text-2xl font-bold text-[var(--primary)] mb-3">Our Approach</h2>
                <p className="text-[var(--muted-foreground)] leading-relaxed">
                  We combine the rigour of traditional legal education with the accessibility and engagement of modern digital platforms. Every note, case and practice question is crafted by experienced Nigerian legal academics and practitioners to ensure accuracy, relevance and examination alignment.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
              {[
                { icon: <BookOpen size={24} />, value: '45+', label: 'Courses' },
                { icon: <Scale size={24} />, value: '500+', label: 'Cases' },
                { icon: <Award size={24} />, value: '700+', label: 'Topics' },
                { icon: <Users size={24} />, value: '2,400+', label: 'Students' },
              ].map((stat) => (
                <div key={stat.label} className="bg-white border border-[var(--border)] rounded-xl p-5 text-center">
                  <div className="flex justify-center text-[var(--primary)] mb-2">{stat.icon}</div>
                  <p className="font-serif text-2xl font-bold text-[var(--primary)]">{stat.value}</p>
                  <p className="text-xs text-[var(--muted-foreground)]">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="bg-[var(--muted)] rounded-2xl p-8 mb-12">
              <h2 className="font-serif text-2xl font-bold text-[var(--primary)] mb-4">Why SJ Law Academy?</h2>
              <div className="grid md:grid-cols-2 gap-x-8 gap-y-3 text-sm text-[var(--foreground)]">
                {[
                  'Curriculum aligned to Nigerian law faculties',
                  'Comprehensive notes written by legal academics',
                  'Real Nigerian case law with clear explanations',
                  'Timed mock examinations with model answers',
                  'Independent level-by-level subscription model',
                  'Mobile-responsive — study anywhere, anytime',
                  'Secure, encrypted data and payments via Paystack',
                  'Continuous content updates reflecting new cases and statutes',
                ].map((item) => (
                  <div key={item} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent)] shrink-0" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="text-center">
            <Link to="/signup" className="inline-flex items-center gap-2 px-8 py-3.5 bg-[var(--primary)] text-white font-semibold rounded-lg hover:bg-[#0a1840] transition-colors">
              Start Your Free Trial <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
