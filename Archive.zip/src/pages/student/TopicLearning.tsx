import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  ChevronLeft, ChevronRight, CheckCircle, BookOpen, Play, List,
  X, Bookmark, BookmarkCheck, Menu,
} from 'lucide-react';
import { MOCK_TOPICS } from '@/data/mockData';

const SAMPLE_NOTES = `
## Offer and Acceptance

The formation of a valid contract under Nigerian law requires, as a threshold requirement, a clear **offer** made by one party (the offeror) and an unequivocal **acceptance** of that offer by another party (the offeree).

### Definition of an Offer

An offer is a definite and unambiguous expression of willingness to be bound by stated terms. The offeror communicates to the offeree that if the offeree accepts, a binding contract will come into existence. The House of Lords in *Carlill v Carbolic Smoke Ball Co* [1893] established that an offer may be made to the world at large.

**Key requirements of a valid offer:**
1. The offer must be **certain and definite** — vague or incomplete communications do not constitute offers
2. The offer must be **communicated** to the offeree before it can be accepted
3. The offeror must demonstrate a **genuine intention** to be bound upon acceptance
4. The offer must be **distinguished from an invitation to treat**

### Invitation to Treat

An invitation to treat is not an offer but merely an indication that the party is willing to receive offers. Critical distinctions:

| Type | Legal Status | Example |
|------|-------------|---------|
| Display of goods | Invitation to treat | Shop window display (*Boots Cash Chemists*) |
| Advertisement (general) | Invitation to treat | Newspaper advertisements |
| Advertisement (specific reward) | Offer | *Carlill v Carbolic Smoke Ball Co* |
| Auction bid | Offer | Subject to auctioneer's acceptance |
| Tender invitation | Invitation to treat | Inviting tenders for construction |

> **Important:** The Nigerian courts follow the English common law position that the display of price-marked goods on a shelf is an invitation to treat and not an offer: *Pharmaceutical Society v Boots* [1953].

### Communication of an Offer

The offer must be communicated to the offeree before it can be accepted. An offeree who is unaware of an offer cannot accept it. This was confirmed in **R v Clarke** (1927) where the defendant was held unable to claim a reward he was unaware of when he provided information.

**Under Nigerian law**, the courts follow the objective test: would a reasonable person in the position of the offeree have understood the communication as an offer? The subjective intention of the offeror is generally irrelevant to this inquiry.

### Termination of an Offer

An offer may be terminated in the following ways:

- **Revocation**: Withdrawal by the offeror before acceptance (must be communicated)
- **Rejection**: Express rejection by the offeree
- **Counter-offer**: A qualified acceptance operates as a rejection (*Hyde v Wrench* [1840])
- **Lapse of time**: Expiry of the specified period or reasonable time
- **Death**: Of either party in certain circumstances
- **Failure of a condition**: Where the offer was subject to a condition
`;

export default function TopicLearning() {
  const { courseId, topicId } = useParams();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<'notes' | 'video'>('notes');
  const [bookmarked, setBookmarked] = useState(false);
  const [completed, setCompleted] = useState(false);

  const currentTopicIndex = MOCK_TOPICS.findIndex((t) => t.id === topicId);
  const currentTopic = MOCK_TOPICS[currentTopicIndex];
  const prevTopic = currentTopicIndex > 0 ? MOCK_TOPICS[currentTopicIndex - 1] : null;
  const nextTopic = currentTopicIndex < MOCK_TOPICS.length - 1 ? MOCK_TOPICS[currentTopicIndex + 1] : null;

  return (
    <div className="min-h-screen flex bg-[var(--background)]">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-72' : 'w-0'} shrink-0 transition-all duration-300 overflow-hidden bg-white border-r border-[var(--border)] flex flex-col`}>
        <div className="p-4 border-b border-[var(--border)]">
          <Link to={`/courses/${courseId}`} className="flex items-center gap-2 text-sm text-[var(--muted-foreground)] hover:text-[var(--primary)] mb-2">
            <ChevronLeft size={14} /> Back to course
          </Link>
          <h3 className="font-serif text-sm font-semibold text-[var(--primary)]">Law of Contract I</h3>
          <p className="text-xs text-[var(--muted-foreground)] mt-0.5">{MOCK_TOPICS.filter((t) => t.completed).length} / {MOCK_TOPICS.length} completed</p>
          <div className="mt-2 h-1.5 bg-[var(--muted)] rounded-full">
            <div className="h-full bg-[var(--primary)] rounded-full" style={{ width: `${(MOCK_TOPICS.filter((t) => t.completed).length / MOCK_TOPICS.length) * 100}%` }} />
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto py-2">
          {MOCK_TOPICS.map((topic, i) => {
            const isActive = topic.id === topicId;
            return (
              <Link
                key={topic.id}
                to={`/courses/${courseId}/topic/${topic.id}`}
                className={`flex items-center gap-3 px-4 py-3 text-sm transition-colors ${
                  isActive ? 'bg-[var(--primary)]/8 text-[var(--primary)] font-medium border-r-2 border-[var(--primary)]' : 'text-[var(--foreground)] hover:bg-[var(--muted)]'
                }`}
              >
                <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 text-[10px] font-mono ${
                  topic.completed ? 'bg-green-500 border-green-500 text-white' : isActive ? 'border-[var(--primary)] text-[var(--primary)]' : 'border-[var(--border)] text-[var(--muted-foreground)]'
                }`}>
                  {topic.completed ? <CheckCircle size={10} /> : i + 1}
                </div>
                <span className="truncate leading-snug">{topic.title}</span>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Toolbar */}
        <div className="bg-white border-b border-[var(--border)] px-4 py-3 flex items-center gap-3">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1.5 rounded-lg hover:bg-[var(--muted)] transition-colors">
            <Menu size={18} />
          </button>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-[var(--muted-foreground)]">Law of Contract I · Topic {currentTopicIndex + 1}</p>
            <p className="text-sm font-semibold text-[var(--foreground)] truncate">{currentTopic?.title}</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex bg-[var(--muted)] rounded-lg p-0.5">
              <button
                onClick={() => setActiveTab('notes')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${activeTab === 'notes' ? 'bg-white shadow-sm text-[var(--primary)]' : 'text-[var(--muted-foreground)]'}`}
              >
                <BookOpen size={13} /> Notes
              </button>
              <button
                onClick={() => setActiveTab('video')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${activeTab === 'video' ? 'bg-white shadow-sm text-[var(--primary)]' : 'text-[var(--muted-foreground)]'}`}
              >
                <Play size={13} /> Video
              </button>
            </div>
            <button
              onClick={() => setBookmarked(!bookmarked)}
              className={`p-2 rounded-lg transition-colors ${bookmarked ? 'text-[var(--accent)] bg-[var(--accent)]/10' : 'text-[var(--muted-foreground)] hover:bg-[var(--muted)]'}`}
            >
              {bookmarked ? <BookmarkCheck size={16} /> : <Bookmark size={16} />}
            </button>
            <button
              onClick={() => setCompleted(!completed)}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors ${
                completed ? 'bg-green-500 text-white' : 'bg-[var(--primary)] text-white hover:bg-[#0a1840]'
              }`}
            >
              <CheckCircle size={13} />
              {completed ? 'Completed' : 'Mark Complete'}
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {activeTab === 'notes' ? (
            <div className="max-w-3xl mx-auto px-6 py-10">
              <NotesRenderer content={SAMPLE_NOTES} />
            </div>
          ) : (
            <div className="max-w-3xl mx-auto px-6 py-10">
              <div className="aspect-video bg-[var(--primary)] rounded-2xl flex items-center justify-center relative overflow-hidden mb-8">
                <div className="absolute inset-0 opacity-10">
                  <div className="w-full h-full" style={{ background: 'radial-gradient(circle at center, white 0%, transparent 70%)' }} />
                </div>
                <div className="text-center text-white">
                  <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4 cursor-pointer hover:bg-white/30 transition-colors">
                    <Play size={28} fill="white" />
                  </div>
                  <p className="font-serif text-xl font-semibold">Offer and Acceptance</p>
                  <p className="text-white/60 text-sm mt-1">22 minutes · Law of Contract I</p>
                </div>
              </div>
              <div className="bg-white border border-[var(--border)] rounded-xl p-5">
                <h3 className="font-serif text-base font-semibold text-[var(--primary)] mb-2">Video Overview</h3>
                <p className="text-sm text-[var(--muted-foreground)] leading-relaxed">
                  This lecture covers the essential elements of offer and acceptance in Nigerian contract law, including the distinction between offers and invitations to treat, communication requirements, and the rules on revocation. Watch alongside the course notes for maximum benefit.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="bg-white border-t border-[var(--border)] px-6 py-4 flex items-center justify-between">
          {prevTopic ? (
            <Link
              to={`/courses/${courseId}/topic/${prevTopic.id}`}
              className="flex items-center gap-2 text-sm text-[var(--foreground)] hover:text-[var(--primary)] transition-colors"
            >
              <ChevronLeft size={16} />
              <div className="text-left hidden sm:block">
                <p className="text-xs text-[var(--muted-foreground)]">Previous</p>
                <p className="font-medium truncate max-w-[200px]">{prevTopic.title}</p>
              </div>
              <span className="sm:hidden">Previous</span>
            </Link>
          ) : <div />}

          <div className="text-xs text-[var(--muted-foreground)] font-mono">
            {currentTopicIndex + 1} / {MOCK_TOPICS.length}
          </div>

          {nextTopic ? (
            <Link
              to={`/courses/${courseId}/topic/${nextTopic.id}`}
              className="flex items-center gap-2 text-sm text-[var(--foreground)] hover:text-[var(--primary)] transition-colors"
            >
              <div className="text-right hidden sm:block">
                <p className="text-xs text-[var(--muted-foreground)]">Next</p>
                <p className="font-medium truncate max-w-[200px]">{nextTopic.title}</p>
              </div>
              <span className="sm:hidden">Next</span>
              <ChevronRight size={16} />
            </Link>
          ) : <div />}
        </div>
      </div>
    </div>
  );
}

function NotesRenderer({ content }: { content: string }) {
  const lines = content.trim().split('\n');
  const elements: React.ReactNode[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    if (line.startsWith('## ')) {
      elements.push(
        <h2 key={i} className="font-serif text-2xl font-bold text-[var(--primary)] mt-8 mb-4 first:mt-0">
          {line.slice(3)}
        </h2>
      );
    } else if (line.startsWith('### ')) {
      elements.push(
        <h3 key={i} className="font-serif text-xl font-semibold text-[var(--primary)] mt-6 mb-3">
          {line.slice(4)}
        </h3>
      );
    } else if (line.startsWith('> ')) {
      elements.push(
        <blockquote key={i} className="border-l-4 border-[var(--accent)] pl-4 py-1 my-4 bg-[var(--accent)]/5 rounded-r-lg">
          <p className="text-sm text-[var(--foreground)] italic">{renderInline(line.slice(2))}</p>
        </blockquote>
      );
    } else if (line.startsWith('| ')) {
      const tableLines: string[] = [];
      while (i < lines.length && lines[i].startsWith('| ')) {
        tableLines.push(lines[i]);
        i++;
      }
      const headers = tableLines[0].split('|').filter(Boolean).map((s) => s.trim());
      const rows = tableLines.slice(2).map((l) => l.split('|').filter(Boolean).map((s) => s.trim()));
      elements.push(
        <div key={i} className="overflow-x-auto my-4">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-[var(--primary)] text-white">
                {headers.map((h, j) => <th key={j} className="px-4 py-2.5 text-left text-xs font-semibold">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, j) => (
                <tr key={j} className={j % 2 === 0 ? 'bg-white' : 'bg-[var(--muted)]'}>
                  {row.map((cell, k) => <td key={k} className="px-4 py-2.5 text-xs border-t border-[var(--border)]">{cell}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
      continue;
    } else if (line.match(/^\d+\. /)) {
      const listItems: string[] = [];
      while (i < lines.length && lines[i].match(/^\d+\. /)) {
        listItems.push(lines[i].replace(/^\d+\. /, ''));
        i++;
      }
      elements.push(
        <ol key={i} className="my-3 space-y-1.5 ml-5 list-decimal text-sm text-[var(--foreground)]">
          {listItems.map((item, j) => <li key={j}>{renderInline(item)}</li>)}
        </ol>
      );
      continue;
    } else if (line.startsWith('- ')) {
      const listItems: string[] = [];
      while (i < lines.length && lines[i].startsWith('- ')) {
        listItems.push(lines[i].slice(2));
        i++;
      }
      elements.push(
        <ul key={i} className="my-3 space-y-1.5 ml-5 list-disc text-sm text-[var(--foreground)]">
          {listItems.map((item, j) => <li key={j}>{renderInline(item)}</li>)}
        </ul>
      );
      continue;
    } else if (line.trim() !== '') {
      elements.push(
        <p key={i} className="text-sm text-[var(--foreground)] leading-7 my-3">
          {renderInline(line)}
        </p>
      );
    }
    i++;
  }

  return <div className="prose-custom">{elements}</div>;
}

function renderInline(text: string): React.ReactNode {
  const parts = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={i} className="font-semibold text-[var(--primary)]">{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith('*') && part.endsWith('*')) {
      return <em key={i}>{part.slice(1, -1)}</em>;
    }
    if (part.startsWith('`') && part.endsWith('`')) {
      return <code key={i} className="font-mono text-xs bg-[var(--muted)] px-1.5 py-0.5 rounded text-[var(--primary)]">{part.slice(1, -1)}</code>;
    }
    return <span key={i}>{part}</span>;
  });
}
