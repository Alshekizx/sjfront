import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, XCircle, ChevronRight, BarChart3, Clock, Star, Flag, ArrowRight } from 'lucide-react';
import { MOCK_PRACTICE_QUESTIONS } from '@/data/mockData';

type Mode = 'home' | 'quiz' | 'results';

export default function Practice() {
  const [mode, setMode] = useState<Mode>('home');
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number[]>([]);
  const [flagged, setFlagged] = useState<number[]>([]);
  const [submitted, setSubmitted] = useState(false);

  function startQuiz() {
    setCurrentQ(0);
    setSelected(Array(MOCK_PRACTICE_QUESTIONS.length).fill(-1));
    setFlagged([]);
    setSubmitted(false);
    setMode('quiz');
  }

  function selectOption(optionIndex: number) {
    if (submitted) return;
    const next = [...selected];
    next[currentQ] = optionIndex;
    setSelected(next);
  }

  function toggleFlag() {
    setFlagged((prev) => prev.includes(currentQ) ? prev.filter((i) => i !== currentQ) : [...prev, currentQ]);
  }

  function submit() {
    setSubmitted(true);
    setTimeout(() => setMode('results'), 800);
  }

  if (mode === 'results') {
    const score = MOCK_PRACTICE_QUESTIONS.filter((q, i) => selected[i] === q.correctOption).length;
    return (
      <div className="min-h-screen bg-[var(--background)]">
        <div className="page-shell max-w-[700px] py-12">
          <div className="bg-white border border-[var(--border)] rounded-2xl p-10 text-center mb-8 shadow-lg">
            <div className={`w-20 h-20 rounded-full mx-auto flex items-center justify-center mb-4 ${score >= MOCK_PRACTICE_QUESTIONS.length / 2 ? 'bg-green-100' : 'bg-red-100'}`}>
              {score >= MOCK_PRACTICE_QUESTIONS.length / 2
                ? <CheckCircle size={40} className="text-green-600" />
                : <XCircle size={40} className="text-red-500" />}
            </div>
            <h2 className="font-serif text-3xl font-bold text-[var(--primary)] mb-2">
              {Math.round((score / MOCK_PRACTICE_QUESTIONS.length) * 100)}%
            </h2>
            <p className="text-[var(--muted-foreground)] mb-4">{score} of {MOCK_PRACTICE_QUESTIONS.length} correct</p>
            <div className="flex justify-center gap-4">
              <button onClick={startQuiz} className="px-6 py-2.5 bg-[var(--primary)] text-white text-sm font-semibold rounded-lg hover:bg-[#0a1840] transition-colors">
                Try Again
              </button>
              <button onClick={() => setMode('home')} className="px-6 py-2.5 border border-[var(--border)] text-sm font-medium rounded-lg hover:bg-[var(--muted)] transition-colors">
                Back to Practice
              </button>
            </div>
          </div>
          <div className="space-y-4">
            {MOCK_PRACTICE_QUESTIONS.map((q, i) => {
              const isCorrect = selected[i] === q.correctOption;
              return (
                <div key={q.id} className="bg-white border border-[var(--border)] rounded-xl p-5">
                  <div className="flex items-start gap-3 mb-3">
                    {isCorrect
                      ? <CheckCircle size={18} className="text-green-500 shrink-0 mt-0.5" />
                      : <XCircle size={18} className="text-red-500 shrink-0 mt-0.5" />}
                    <p className="text-sm font-medium text-[var(--foreground)]">{q.question}</p>
                  </div>
                  <div className="space-y-1.5 mb-3">
                    {q.options.map((opt, j) => (
                      <div key={j} className={`px-3 py-2 rounded-lg text-xs ${
                        j === q.correctOption ? 'bg-green-50 text-green-700 border border-green-200' :
                        j === selected[i] && !isCorrect ? 'bg-red-50 text-red-600 border border-red-200' : 'bg-[var(--muted)] text-[var(--muted-foreground)]'
                      }`}>
                        {opt}
                      </div>
                    ))}
                  </div>
                  <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
                    <p className="text-xs font-semibold text-blue-800 mb-1">Explanation</p>
                    <p className="text-xs text-blue-700 leading-relaxed">{q.explanation}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'quiz') {
    const q = MOCK_PRACTICE_QUESTIONS[currentQ];
    const selectedForCurrent = selected[currentQ];
    return (
      <div className="min-h-screen bg-[var(--background)]">
        <div className="page-shell max-w-[700px] py-10">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-xs text-[var(--muted-foreground)]">Question {currentQ + 1} of {MOCK_PRACTICE_QUESTIONS.length}</p>
              <div className="flex gap-1 mt-1.5">
                {MOCK_PRACTICE_QUESTIONS.map((_, i) => (
                  <button key={i} onClick={() => setCurrentQ(i)} className={`h-1.5 rounded-full transition-all ${
                    i === currentQ ? 'w-6 bg-[var(--primary)]' :
                    selected[i] >= 0 ? 'w-3 bg-[var(--accent)]' : 'w-3 bg-[var(--border)]'
                  }`} />
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={toggleFlag} className={`p-2 rounded-lg transition-colors ${flagged.includes(currentQ) ? 'text-amber-500 bg-amber-50' : 'text-[var(--muted-foreground)] hover:bg-[var(--muted)]'}`}>
                <Flag size={16} />
              </button>
              <button onClick={submit} className="px-4 py-2 bg-[var(--primary)] text-white text-xs font-semibold rounded-lg hover:bg-[#0a1840] transition-colors">
                Submit
              </button>
            </div>
          </div>

          {/* Question */}
          <div className="bg-white border border-[var(--border)] rounded-2xl p-6 mb-4 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <span className="font-mono text-xs bg-[var(--muted)] text-[var(--muted-foreground)] px-2.5 py-1 rounded-full">{q.type}</span>
              <span className="font-mono text-xs bg-[var(--muted)] text-[var(--muted-foreground)] px-2.5 py-1 rounded-full">{q.difficulty}</span>
              <span className="text-xs text-[var(--muted-foreground)] ml-auto">{q.course}</span>
            </div>
            <p className="text-base text-[var(--foreground)] leading-relaxed font-medium">{q.question}</p>
          </div>

          {/* Options */}
          <div className="space-y-3 mb-8">
            {q.options.map((opt, i) => (
              <button
                key={i}
                onClick={() => selectOption(i)}
                className={`w-full text-left px-4 py-3.5 rounded-xl border text-sm transition-all ${
                  selectedForCurrent === i
                    ? 'bg-[var(--primary)] text-white border-[var(--primary)]'
                    : 'bg-white border-[var(--border)] hover:border-[var(--primary)]/30 hover:bg-[var(--muted)]'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <button
              disabled={currentQ === 0}
              onClick={() => setCurrentQ(currentQ - 1)}
              className="px-5 py-2.5 border border-[var(--border)] text-sm font-medium rounded-lg disabled:opacity-40 hover:bg-[var(--muted)] transition-colors"
            >
              Previous
            </button>
            {currentQ < MOCK_PRACTICE_QUESTIONS.length - 1 ? (
              <button
                onClick={() => setCurrentQ(currentQ + 1)}
                disabled={selectedForCurrent < 0}
                className="flex items-center gap-2 px-5 py-2.5 bg-[var(--primary)] text-white text-sm font-semibold rounded-lg disabled:opacity-40 hover:bg-[#0a1840] transition-colors"
              >
                Next <ChevronRight size={15} />
              </button>
            ) : (
              <button
                onClick={submit}
                className="flex items-center gap-2 px-5 py-2.5 bg-green-600 text-white text-sm font-semibold rounded-lg hover:bg-green-700 transition-colors"
              >
                Submit All <CheckCircle size={15} />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="page-shell py-10">
        <div className="mb-8">
          <h1 className="font-serif text-3xl font-bold text-[var(--primary)]">Practice & Examinations</h1>
          <p className="text-[var(--muted-foreground)] mt-1">Test your knowledge with questions tailored to your courses</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {[
            { title: 'MCQ Practice', icon: <Star size={24} />, desc: 'Multiple choice questions by topic and difficulty', count: '48 available', color: 'bg-blue-500', action: startQuiz },
            { title: 'Past Questions', icon: <Clock size={24} />, desc: 'Previous examination questions with model answers', count: '124 questions', color: 'bg-purple-500', action: startQuiz },
            { title: 'Mock Examination', icon: <BarChart3 size={24} />, desc: 'Timed examination with full result review', count: '2 available', color: 'bg-[var(--primary)]', action: startQuiz },
          ].map((item) => (
            <div key={item.title} className="bg-white border border-[var(--border)] rounded-2xl p-6 hover:shadow-lg transition-shadow">
              <div className={`w-12 h-12 rounded-xl ${item.color} text-white flex items-center justify-center mb-4`}>
                {item.icon}
              </div>
              <h3 className="font-serif text-xl font-semibold text-[var(--primary)] mb-1">{item.title}</h3>
              <p className="text-sm text-[var(--muted-foreground)] mb-4">{item.desc}</p>
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs bg-[var(--muted)] text-[var(--muted-foreground)] px-2.5 py-1 rounded-full">{item.count}</span>
                <button onClick={item.action} className="flex items-center gap-1.5 text-sm font-semibold text-[var(--primary)] hover:underline">
                  Start <ArrowRight size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white border border-[var(--border)] rounded-2xl p-6">
          <h2 className="font-serif text-xl font-semibold text-[var(--primary)] mb-4">Recent Practice Sessions</h2>
          <div className="space-y-3">
            {[
              { date: '20 Sep 2026', type: 'MCQ', course: 'Law of Contract I', score: '8/10', pct: 80 },
              { date: '17 Sep 2026', type: 'MCQ', course: 'Law of Torts', score: '6/10', pct: 60 },
              { date: '14 Sep 2026', type: 'Past Questions', course: 'Constitutional Law', score: '14/20', pct: 70 },
            ].map((session, i) => (
              <div key={i} className="flex items-center gap-4 p-3.5 bg-[var(--muted)] rounded-xl">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-sm ${session.pct >= 70 ? 'bg-green-500' : 'bg-amber-500'}`}>
                  {session.pct}%
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[var(--foreground)]">{session.type} · {session.course}</p>
                  <p className="text-xs text-[var(--muted-foreground)]">{session.date} · {session.score} correct</p>
                </div>
                <button className="text-xs text-[var(--primary)] font-medium">Review →</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
