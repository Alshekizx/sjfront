import { BarChart3, CheckCircle, TrendingUp, Award, Clock, BookOpen } from 'lucide-react';
import { MOCK_COURSES, MOCK_ACTIVITY } from '@/data/mockData';

export default function Progress() {
  const overallPct = Math.round(MOCK_COURSES.reduce((s, c) => s + (c.completedTopics / c.topics), 0) / MOCK_COURSES.length * 100);

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="page-shell py-10">
        <div className="mb-8">
          <h1 className="font-serif text-3xl font-bold text-[var(--primary)]">My Progress</h1>
          <p className="text-[var(--muted-foreground)] mt-1">200 Level · Academic Year 2026</p>
        </div>

        {/* Summary stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { icon: <BookOpen size={20} />, label: 'Courses Enrolled', value: '4', sub: '200 Level' },
            { icon: <CheckCircle size={20} />, label: 'Topics Completed', value: '17', sub: 'of 68 total' },
            { icon: <TrendingUp size={20} />, label: 'Practice Accuracy', value: '74%', sub: '20 questions avg' },
            { icon: <Award size={20} />, label: 'Courses Completed', value: '1', sub: 'Constitutional Law' },
          ].map((stat) => (
            <div key={stat.label} className="bg-white border border-[var(--border)] rounded-xl p-5">
              <div className="w-9 h-9 rounded-lg bg-[var(--primary)]/8 flex items-center justify-center text-[var(--primary)] mb-3">{stat.icon}</div>
              <p className="font-serif text-2xl font-bold text-[var(--primary)]">{stat.value}</p>
              <p className="text-xs text-[var(--muted-foreground)] mt-0.5">{stat.sub}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Overall Progress */}
          <div className="bg-white border border-[var(--border)] rounded-xl p-6">
            <h2 className="font-serif text-xl font-semibold text-[var(--primary)] mb-5">Level Progress</h2>
            <div className="flex items-center gap-6 mb-6">
              <div className="w-24 h-24 rounded-full border-8 border-[var(--primary)] flex items-center justify-center">
                <div>
                  <p className="font-serif text-2xl font-bold text-[var(--primary)] text-center">{overallPct}%</p>
                  <p className="text-[8px] text-[var(--muted-foreground)] text-center">Overall</p>
                </div>
              </div>
              <div className="flex-1 space-y-3">
                {MOCK_COURSES.map((course) => {
                  const pct = Math.round((course.completedTopics / course.topics) * 100);
                  return (
                    <div key={course.id}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-[var(--foreground)] truncate">{course.title}</span>
                        <span className="text-xs font-mono text-[var(--primary)] ml-2">{pct}%</span>
                      </div>
                      <div className="h-2 bg-[var(--muted)] rounded-full">
                        <div className={`h-full rounded-full ${pct === 100 ? 'bg-green-500' : 'bg-[var(--primary)]'}`} style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Practice performance */}
          <div className="bg-white border border-[var(--border)] rounded-xl p-6">
            <h2 className="font-serif text-xl font-semibold text-[var(--primary)] mb-5">Practice Performance</h2>
            <div className="space-y-4">
              {[
                { course: 'Law of Contract I', sessions: 5, avgScore: 78, trend: '+8%' },
                { course: 'Law of Torts', sessions: 3, avgScore: 65, trend: '+5%' },
                { course: 'Constitutional Law I', sessions: 8, avgScore: 88, trend: '+12%' },
                { course: 'Land Law', sessions: 1, avgScore: 60, trend: 'New' },
              ].map((item) => (
                <div key={item.course} className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-sm text-white ${
                    item.avgScore >= 80 ? 'bg-green-500' : item.avgScore >= 65 ? 'bg-[var(--primary)]' : 'bg-amber-500'
                  }`}>
                    {item.avgScore}%
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[var(--foreground)] truncate">{item.course}</p>
                    <p className="text-xs text-[var(--muted-foreground)]">{item.sessions} sessions</p>
                  </div>
                  <span className={`text-xs font-semibold ${item.trend.startsWith('+') ? 'text-green-600' : 'text-[var(--muted-foreground)]'}`}>
                    {item.trend}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Activity timeline */}
          <div className="lg:col-span-2 bg-white border border-[var(--border)] rounded-xl p-6">
            <h2 className="font-serif text-xl font-semibold text-[var(--primary)] mb-5">Recent Learning Activity</h2>
            <div className="space-y-4">
              {MOCK_ACTIVITY.map((activity, i) => (
                <div key={i} className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[var(--muted)] flex items-center justify-center shrink-0">
                    <Clock size={16} className="text-[var(--muted-foreground)]" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-[var(--foreground)]">
                      <span className="text-[var(--muted-foreground)]">{activity.action}</span> {activity.item}
                    </p>
                    <p className="text-xs text-[var(--muted-foreground)]">{activity.course}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs font-medium text-[var(--foreground)]">{activity.duration}</p>
                    <p className="text-xs text-[var(--muted-foreground)]">{new Date(activity.date).toLocaleDateString('en-NG', { day: 'numeric', month: 'short' })}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
