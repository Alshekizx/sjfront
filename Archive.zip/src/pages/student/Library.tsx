import { Bookmark, Scale, BookOpen, Play, FileText } from 'lucide-react';
import { MOCK_CASES, MOCK_TOPICS } from '@/data/mockData';
import { Link } from 'react-router-dom';

export default function Library() {
  const bookmarkedCases = MOCK_CASES.filter((c) => c.bookmarked);
  const bookmarkedTopics = MOCK_TOPICS.filter((t) => t.id === 't001' || t.id === 't002');

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="page-shell py-10">
        <div className="mb-8">
          <h1 className="font-serif text-3xl font-bold text-[var(--primary)]">My Library</h1>
          <p className="text-[var(--muted-foreground)] mt-1">Saved notes, cases, topics and resources</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Bookmarked cases */}
          <div className="bg-white border border-[var(--border)] rounded-xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Scale size={18} className="text-[var(--accent)]" />
              <h2 className="font-serif text-lg font-semibold text-[var(--primary)]">Saved Cases</h2>
              <span className="ml-auto font-mono text-xs bg-[var(--muted)] text-[var(--muted-foreground)] px-2 py-0.5 rounded-full">{bookmarkedCases.length}</span>
            </div>
            <div className="space-y-3">
              {bookmarkedCases.map((c) => (
                <div key={c.id} className="p-3.5 bg-[var(--muted)] rounded-xl hover:bg-[var(--secondary)] transition-colors">
                  <p className="text-sm font-semibold text-[var(--primary)]">{c.name}</p>
                  <p className="font-mono text-xs text-[var(--muted-foreground)] mt-0.5">{c.citation}</p>
                  <p className="text-xs text-[var(--foreground)] mt-1.5 line-clamp-2">{c.principle}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-[10px] bg-white text-[var(--muted-foreground)] px-2 py-0.5 rounded-full">{c.topic}</span>
                  </div>
                </div>
              ))}
              <Link to="/case-law" className="block text-center py-3 border border-dashed border-[var(--border)] rounded-xl text-xs font-medium text-[var(--muted-foreground)] hover:border-[var(--primary)] hover:text-[var(--primary)] transition-colors">
                Browse case library →
              </Link>
            </div>
          </div>

          {/* Bookmarked topics */}
          <div className="bg-white border border-[var(--border)] rounded-xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Bookmark size={18} className="text-[var(--accent)]" />
              <h2 className="font-serif text-lg font-semibold text-[var(--primary)]">Saved Topics</h2>
              <span className="ml-auto font-mono text-xs bg-[var(--muted)] text-[var(--muted-foreground)] px-2 py-0.5 rounded-full">{bookmarkedTopics.length}</span>
            </div>
            <div className="space-y-3">
              {bookmarkedTopics.map((t) => (
                <Link key={t.id} to={`/courses/c001/topic/${t.id}`} className="flex items-center gap-3 p-3.5 bg-[var(--muted)] rounded-xl hover:bg-[var(--secondary)] transition-colors">
                  <div className="w-9 h-9 rounded-lg bg-[var(--primary)]/8 flex items-center justify-center">
                    <FileText size={16} className="text-[var(--primary)]" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-[var(--foreground)]">{t.title}</p>
                    <p className="text-xs text-[var(--muted-foreground)]">Law of Contract I</p>
                  </div>
                  <div className="ml-auto flex items-center gap-1.5">
                    {t.hasVideo && <Play size={12} className="text-[var(--muted-foreground)]" />}
                    {t.hasNotes && <BookOpen size={12} className="text-[var(--muted-foreground)]" />}
                  </div>
                </Link>
              ))}
              <Link to="/courses" className="block text-center py-3 border border-dashed border-[var(--border)] rounded-xl text-xs font-medium text-[var(--muted-foreground)] hover:border-[var(--primary)] hover:text-[var(--primary)] transition-colors">
                Browse courses →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
