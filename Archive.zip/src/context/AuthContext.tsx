import { createContext, useContext, useState, ReactNode } from 'react';

export interface Subscription {
  level: number;
  levelName: string;
  status: 'active' | 'trial' | 'expired';
  startDate: string;
  expiryDate: string;
  price: number;
  reference: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  university: string;
  academicLevel: number;
  avatar?: string;
  trialStartDate: string;
  trialExpiryDate: string;
  subscriptions: Subscription[];
  unreadNotifications: number;
}

interface AuthContextValue {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  signup: (data: SignupData) => Promise<void>;
}

interface SignupData {
  name: string;
  email: string;
  password: string;
  university: string;
  academicLevel: number;
  phone: string;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const MOCK_USER: User = {
  id: 'usr_001',
  name: 'Adaeze Okafor',
  email: 'adaeze.okafor@unilag.edu.ng',
  phone: '+234 803 456 7890',
  university: 'University of Lagos',
  academicLevel: 2,
  trialStartDate: '2026-09-18',
  trialExpiryDate: '2026-09-21',
  unreadNotifications: 3,
  subscriptions: [
    {
      level: 1,
      levelName: '100 Level',
      status: 'active',
      startDate: '2026-08-01',
      expiryDate: '2026-12-31',
      price: 12000,
      reference: 'PSK_REF_001_20260801',
    },
    {
      level: 2,
      levelName: '200 Level',
      status: 'trial',
      startDate: '2026-09-18',
      expiryDate: '2026-09-21',
      price: 0,
      reference: 'TRIAL_002_20260918',
    },
  ],
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (_email: string, _password: string) => {
    await new Promise((r) => setTimeout(r, 1000));
    setUser(MOCK_USER);
  };

  const logout = () => setUser(null);

  const signup = async (_data: SignupData) => {
    await new Promise((r) => setTimeout(r, 1200));
    setUser({ ...MOCK_USER, name: _data.name, email: _data.email });
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, logout, signup }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
